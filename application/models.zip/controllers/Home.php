<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('login_signup');
	}

	public function index()
	{
		$view['code']=false;
		$view['message']="";
		$this->load->view('main/index.php',$view);
	}

	public function signUp()
	{
		$data = array(
	        'teamName' => $this->input->post('teamName'),
			'name' => $this->input->post('name'),
			'contact' => $this->input->post('contact'),
			'email' => $this->input->post('email'),
			'password' => sha1($this->input->post('password')),
	        'datetime' => date('Y-m-d H:i:s')

		);

		if($this->login_signup->signUp($data))
		{

			// $this->email->from("support@Knifemaster.in", "Knifemaster Gaming");
			// $this->email->to('knightgaming1222@gmail.com');
			 
			// $this->email->subject('Contacting  from Knifemaster gaming website');
			// $this->email->message($cf_message.' Contact no:-'.$cf_number);

			// $this->email->send();

			// $this->email->from("support@Knifemaster.in", "Knifemaster Gaming");
			// $this->email->to($this->input->post('email'));
			 
			// $this->email->subject('Contacting  from Knifemaster gaming website');
			// $this->email->message($cf_message.' Contact no:-'.$cf_number);

			// $this->email->send();
			$view['code']=true;
			$view['message']="Account Created Sucessfully";
			$this->load->view('main/index.php', $view);
		}
		else
		{
			$view['code']=false;
			$view['message']="Error in creating Your Account";

			$this->load->view('main/index.php', $view);	
		}
		

	}

	public function loginUser()
	{
		$email = $this->input->post('email');
		$password = sha1($this->input->post('password'));

		if($msg=$this->login_signup->loginUser($email,$password))
		{
			$view['code']=true;
			$view['message']="You are ready for Login";

			$this->load->view('main/index.php', $view);		
		}
		else
		{
			$view['code']=false;
			$view['message']="Error in your email or password";

			$this->load->view('main/index.php', $view);	
		}
	}
}
